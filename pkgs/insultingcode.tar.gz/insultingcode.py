# insultingCode
# be insulted
# Developed by Alexander. (https://github.com/bigjiminboy

import random
intros = ["hey bitch, what\'s your name?", "sup fucker, what\'s your name?", "hey fuckface, what\'s your name?", "give me your name ya daft twat", "give me your name you dumb cunt", "tell me your name, you ugly motherfucker", "hey baby, what\'s your name?"]
print(random.choice(intros))
name = input("")
name = str(name)
insults = ["ur a bitch", "you\'re a motel cumstain", "go fuck yourself", "you have no friends", "you\'re gonna die a virgin", "you're a real cunt", "no one loves you", "shove a 12 foot steel pole up your ass", "i hope your house gets infested", "i have a trained sniper on your position", "i hope you die soon", "ur mums fat", "have a lovely day"]
print(random.choice(insults), name)